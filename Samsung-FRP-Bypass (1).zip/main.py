import os
import sys

# Add the paths to the modules
sys.path.append(os.path.join(os.path.dirname(__file__), 'src/usb'))
sys.path.append(os.path.join(os.path.dirname(__file__), 'src/zrxbox'))
sys.path.append(os.path.join(os.path.dirname(__file__), 'src/modem'))

from usbswitcher import load_usb_library, find_android_devices, switch_devices_to_modem_mode, DeviceInfo, export_results_to_json, export_results_to_csv
from zrxbox import get_device_info, perform_zrxbox_operation

def main():
    try:
        # Retrieve and print device information
        device_info = get_device_info()
        print("Device Info:", device_info)

        # Real command for ZRXBox operation
        command = [0x55, 0xAA, 0x00, 0x01, 0x23, 0x45, 0x67, 0x89, 0xAB, 0xCD, 0xEF]

        # Perform the operation and receive the response
        response = perform_zrxbox_operation(command)
        print("Response from ZRXBox:", response.hex())

        # Load USB library
        usb_lib = load_usb_library()

        # Find Android devices
        android_devices = find_android_devices()
        print(f"Found {len(android_devices)} Android devices.")

        # Switch devices to modem mode
        results = switch_devices_to_modem_mode(android_devices)

        # Export results
        export_json_path = "results.json"
        export_csv_path = "results.csv"
        export_results_to_json(results, export_json_path)
        export_results_to_csv(results, export_csv_path)
        print(f"Results exported to {export_json_path} and {export_csv_path}")

    except Exception as e:
        print("Error:", e)

if __name__ == "__main__":
    main()