import serial
import serial.tools.list_ports as prtlst
from serial.tools import list_ports_common
import time
import logging
from typing import List, Optional
import argparse
import sys
import subprocess

# Set up logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

SERIAL_BAUDRATE = 115200
SERIAL_TIMEOUT = 12
MAX_RETRIES = 3
RETRY_DELAY = 1.0

def adb(cmd: str) -> int:
    full_cmd = f"adb {cmd}"
    logger.debug(f"Executing ADB command: {full_cmd}")
    return subprocess.call(full_cmd, shell=True)

def list_serial_ports() -> List[list_ports_common.ListPortInfo]:
    ports = prtlst.comports()
    if not ports:
        logger.error("No serial port available")
        sys.exit(1)
    logger.info("Available serial ports:")
    for port in ports:
        logger.info(f"  {port}")
    return ports

def get_AT_serial(port: str) -> serial.Serial:
    try:
        return serial.Serial(port, baudrate=SERIAL_BAUDRATE, timeout=SERIAL_TIMEOUT)
    except serial.SerialException as e:
        logger.error(f"Failed to open serial port {port}: {e}")
        sys.exit(1)

def ATSend(io: serial.Serial, cmd: str, retries: int = MAX_RETRIES) -> bool:
    if not io.isOpen():
        logger.error("Serial port is not open")
        return False

    for attempt in range(retries):
        try:
            logger.debug(f"Sending: {cmd.strip()}")
            io.write(cmd.encode())
            time.sleep(0.5)
            ret = io.read_all()
            logger.debug(f"Received: {ret}")

            if b"OK\r\n" in ret:
                return True
            if b"ERROR\r\n" in ret:
                logger.warning(f"Command failed: {cmd.strip()}")
                return False
            if ret == b"\r\n" or ret == b'' or ret == cmd.encode():
                logger.warning(f"Unexpected response: {ret}")

            if attempt < retries - 1:
                logger.info(f"Retrying command: {cmd.strip()}")
                time.sleep(RETRY_DELAY)
            else:
                logger.error(f"Command failed after {retries} attempts: {cmd.strip()}")
                return False
        except serial.SerialException as e:
            logger.error(f"Serial communication error: {e}")
            return False

    return True

def tryATCmds(io: serial.Serial, cmds: List[str]):
    for i, cmd in enumerate(cmds):
        logger.info(f"Trying method {i + 1}")
        try:
            res = ATSend(io, cmd)
            if res:
                logger.info(f"Command successful: {cmd.strip()}")
            else:
                logger.warning(f"Command failed: {cmd.strip()}")
        except Exception as e:
            logger.error(f"Error while sending command {cmd.strip()}: {e}")

    try:
        io.close()
    except:
        logger.warning("Unable to properly close serial connection")

def enableADB(port: Optional[str] = None):
    if not port:
        ports = list_serial_ports()
        default_port = ports[0].device
        port = input(f"Choose a serial port (default={default_port}): ") or default_port

    io = get_AT_serial(port)
    logger.info("Initializing...")
    ATSend(io, "AT+KSTRINGB=0,3\r\n")

    logger.info("Go to emergency dialer and enter *#0*#, press enter when done")
    input()

    logger.info("Enabling USB Debugging...")
    cmds = [
        "AT+DUMPCTRL=1,0\r\n",
        "AT+DEBUGLVC=0,5\r\n",
        "AT+SWATD=0\r\n",
        "AT+ACTIVATE=0,0,0\r\n",
        "AT+SWATD=1\r\n",
        "AT+DEBUGLVC=0,5\r\n"
    ]
    tryATCmds(io, cmds)

    logger.info("USB Debugging should be enabled")
    logger.info("If USB Debugging prompt does not appear, try unplugging and replugging the USB cable")

def uploadAndRunFRPBypass():
    logger.info("Pushing FRP bypasser binary")
    adb("push frp.bin /data/local/tmp/temp")
    logger.info("Giving it 777 permissions")
    adb("shell chmod 777 /data/local/tmp/temp")
    logger.info("Executing the binary")
    adb("shell /data/local/tmp/temp")

def manualFRPBypass():
    logger.info("Bypassing FRP...")
    cmds = [
        "settings put global setup_wizard_has_run 1",
        "settings put secure user_setup_complete 1",
        "content insert --uri content://settings/secure --bind name:s:DEVICE_PROVISIONED --bind value:i:1",
        "content insert --uri content://settings/secure --bind name:s:user_setup_complete --bind value:i:1",
        "content insert --uri content://settings/secure --bind name:s:INSTALL_NON_MARKET_APPS --bind value:i:1",
        "am start -c android.intent.category.HOME -a android.intent.action.MAIN"
    ]
    for cmd in cmds:
        adb(f"shell {cmd}")
    time.sleep(5)
    adb("shell am start -n com.android.settings/com.android.settings.Settings")
    time.sleep(5)
    logger.info("FRP bypass completed")
    logger.info("For complete reset FRP, go to 'Backup and reset' and perform 'Factory data reset'")
    logger.info("Rebooting...")
    adb("shell reboot")
    logger.info("Device reboot initiated")

def waitForDevice():
    logger.info("Waiting for device with adb")
    adb("kill-server")
    adb("wait-for-device")

def parse_arguments():
    parser = argparse.ArgumentParser(description="Enable ADB and bypass FRP on Android devices.")
    parser.add_argument("-p", "--port", help="Specify the serial port to use")
    parser.add_argument("-v", "--verbose", action="store_true", help="Enable verbose logging")
    parser.add_argument("--manual", action="store_true", help="Use manual FRP bypass instead of binary")
    return parser.parse_args()

def main():
    args = parse_arguments()
    if args.verbose:
        logger.setLevel(logging.DEBUG)

    try:
        enableADB(args.port)
        waitForDevice()
        if args.manual:
            manualFRPBypass()
        else:
            uploadAndRunFRPBypass()
    except KeyboardInterrupt:
        logger.info("Operation interrupted by user")
        sys.exit(1)
    except Exception as e:
        logger.exception("An unexpected error occurred")
        sys.exit(1)

if __name__ == "__main__":
    main()