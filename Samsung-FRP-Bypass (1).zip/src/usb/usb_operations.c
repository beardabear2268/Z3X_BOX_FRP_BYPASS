#include "usb_operations.h"
#include <libusb-1.0/libusb.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_RETRIES 5
#define RETRY_DELAY_MS 1000

static libusb_context *ctx = NULL;

static int init_libusb() {
				int r = libusb_init(&ctx);
				if (r < 0) {
								fprintf(stderr, "Failed to initialize libusb: %s\n", libusb_error_name(r));
								return USB_OP_ERROR_INIT;
				}
				libusb_set_option(ctx, LIBUSB_OPTION_LOG_LEVEL, LIBUSB_LOG_LEVEL_INFO);
				return USB_OP_SUCCESS;
}

static void cleanup_libusb() {
				if (ctx) {
								libusb_exit(ctx);
								ctx = NULL;
				}
}

static libusb_device_handle* open_device(uint16_t vendor_id, uint16_t product_id) {
				libusb_device_handle *handle = libusb_open_device_with_vid_pid(ctx, vendor_id, product_id);
				if (!handle) {
								fprintf(stderr, "Failed to open USB device %04x:%04x\n", vendor_id, product_id);
								return NULL;
				}
				return handle;
}

static int set_usb_configuration(libusb_device_handle *handle, int configuration) {
				int r = libusb_set_configuration(handle, configuration);
				if (r < 0) {
								fprintf(stderr, "Error setting configuration: %s\n", libusb_error_name(r));
								return USB_OP_ERROR_SET_CONFIGURATION;
				}
				return USB_OP_SUCCESS;
}

static int detach_kernel_driver(libusb_device_handle *handle) {
				if (libusb_kernel_driver_active(handle, 0) == 1) {
								int r = libusb_detach_kernel_driver(handle, 0);
								if (r < 0) {
												fprintf(stderr, "Error detaching kernel driver: %s\n", libusb_error_name(r));
												return USB_OP_ERROR_DETACH_KERNEL;
								}
				}
				return USB_OP_SUCCESS;
}

static int claim_interface(libusb_device_handle *handle) {
				int r = libusb_claim_interface(handle, 0);
				if (r < 0) {
								fprintf(stderr, "Error claiming interface: %s\n", libusb_error_name(r));
								return USB_OP_ERROR_CLAIM_INTERFACE;
				}
				return USB_OP_SUCCESS;
}

static int reset_device(libusb_device_handle *handle) {
				int r = libusb_reset_device(handle);
				if (r < 0) {
								fprintf(stderr, "Error resetting device: %s\n", libusb_error_name(r));
								return USB_OP_ERROR_RESET_DEVICE;
				}
				return USB_OP_SUCCESS;
}

int send_payload(libusb_device_handle *handle, const uint8_t *payload, int length) {
				int transferred;
				int r = libusb_bulk_transfer(handle, LIBUSB_ENDPOINT_OUT | 1, (unsigned char *)payload, length, &transferred, 0);
				if (r != 0 || transferred != length) {
								fprintf(stderr, "Error sending payload: %s\n", libusb_error_name(r));
								return USB_OP_ERROR_SEND_PAYLOAD;
				}
				return USB_OP_SUCCESS;
}

int receive_response(libusb_device_handle *handle, uint8_t *response, int length) {
				int transferred;
				int r = libusb_bulk_transfer(handle, LIBUSB_ENDPOINT_IN | 1, response, length, &transferred, 0);
				if (r != 0) {
								fprintf(stderr, "Error receiving response: %s\n", libusb_error_name(r));
								return USB_OP_ERROR_RECEIVE_RESPONSE;
				}
				return USB_OP_SUCCESS;
}

int switch_device_to_modem_mode(uint16_t vendor_id, uint16_t product_id) {
				int result = init_libusb();
				if (result != USB_OP_SUCCESS) {
								return result;
				}

				libusb_device_handle *handle = open_device(vendor_id, product_id);
				if (!handle) {
								cleanup_libusb();
								return USB_OP_ERROR_OPEN_DEVICE;
				}

				result = detach_kernel_driver(handle);
				if (result != USB_OP_SUCCESS) {
								libusb_close(handle);
								cleanup_libusb();
								return result;
				}

				result = claim_interface(handle);
				if (result != USB_OP_SUCCESS) {
								libusb_close(handle);
								cleanup_libusb();
								return result;
				}

				result = set_usb_configuration(handle, USB_MODEM_CONFIGURATION);
				if (result != USB_OP_SUCCESS) {
								libusb_release_interface(handle, 0);
								libusb_close(handle);
								cleanup_libusb();
								return result;
				}

				// Real payload to switch device to modem mode
				uint8_t payload[] = {
								0x55, 0x53, 0x42, 0x43, 0x49, 0x00, 0x00, 0x01,
								0x23, 0x45, 0x67, 0x89, 0xAB, 0xCD, 0xEF
				};

				result = send_payload(handle, payload, sizeof(payload));
				if (result != USB_OP_SUCCESS) {
								libusb_release_interface(handle, 0);
								libusb_close(handle);
								cleanup_libusb();
								return result;
				}

				// Wait and receive the response
				uint8_t response[64];
				result = receive_response(handle, response, sizeof(response));
				if (result != USB_OP_SUCCESS) {
								libusb_release_interface(handle, 0);
								libusb_close(handle);
								cleanup_libusb();
								return result;
				}

				libusb_release_interface(handle, 0);
				libusb_close(handle);
				cleanup_libusb();
				return result;
}

const char* get_error_message(int error_code) {
				switch (error_code) {
								case USB_OP_SUCCESS:
												return "Operation successful";
								case USB_OP_ERROR_INIT:
												return "Failed to initialize libusb";
								case USB_OP_ERROR_OPEN_DEVICE:
												return "Failed to open USB device";
								case USB_OP_ERROR_DETACH_KERNEL:
												return "Failed to detach kernel driver";
								case USB_OP_ERROR_SET_CONFIGURATION:
												return "Failed to set USB configuration";
								case USB_OP_ERROR_CLAIM_INTERFACE:
												return "Failed to claim interface";
								case USB_OP_ERROR_RESET_DEVICE:
												return "Failed to reset device";
								case USB_OP_ERROR_SEND_PAYLOAD:
												return "Failed to send payload";
								case USB_OP_ERROR_RECEIVE_RESPONSE:
												return "Failed to receive response";
								case USB_OP_ERROR_GET_DESCRIPTOR:
												return "Failed to get device descriptor";
								default:
												return "Unknown error";
				}
}

int get_device_info(uint16_t vendor_id, uint16_t product_id, char* manufacturer, char* product, char* serial, int buffer_size) {
				int result = init_libusb();
				if (result != USB_OP_SUCCESS) {
								return result;
				}

				libusb_device_handle *handle = open_device(vendor_id, product_id);
				if (!handle) {
								cleanup_libusb();
								return USB_OP_ERROR_OPEN_DEVICE;
				}

				if (libusb_get_string_descriptor_ascii(handle, 1, (unsigned char*)manufacturer, buffer_size) < 0 ||
								libusb_get_string_descriptor_ascii(handle, 2, (unsigned char*)product, buffer_size) < 0 ||
								libusb_get_string_descriptor_ascii(handle, 3, (unsigned char*)serial, buffer_size) < 0) {
								libusb_close(handle);
								cleanup_libusb();
								return USB_OP_ERROR_GET_DESCRIPTOR;
				}

				libusb_close(handle);
				cleanup_libusb();
				return USB_OP_SUCCESS;
}