#ifndef POC_H
#define POC_H

#include <stdint.h>

int check_poc(uint8_t* response, int response_length);

#endif // POC_H